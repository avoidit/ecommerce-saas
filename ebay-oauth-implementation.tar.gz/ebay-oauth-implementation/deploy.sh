#!/bin/bash

# eBay OAuth Integration - Automated Deployment Script
# This script automates the deployment of the eBay OAuth integration

set -e  # Exit on error

echo "========================================"
echo "eBay OAuth Integration Deployment"
echo "========================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Check if running from correct directory
if [ ! -f "docker-compose.yml" ]; then
    print_error "docker-compose.yml not found!"
    print_error "Please run this script from your ecommerce-saas directory"
    exit 1
fi

print_success "Found docker-compose.yml"

# Check if implementation directory exists
if [ ! -d "ebay-oauth-implementation" ]; then
    print_error "ebay-oauth-implementation directory not found!"
    print_error "Please extract the implementation files first"
    exit 1
fi

print_success "Found implementation files"

echo ""
echo "Step 1: Copying migration files..."
cp ebay-oauth-implementation/migrations/*.php database/migrations/
print_success "Migrations copied"

echo ""
echo "Step 2: Copying model files..."
cp ebay-oauth-implementation/models/*.php app/Models/
print_success "Models copied"

echo ""
echo "Step 3: Creating Services directory and copying service files..."
mkdir -p app/Services
cp ebay-oauth-implementation/services/*.php app/Services/
print_success "Services copied"

echo ""
echo "Step 4: Copying job files..."
cp ebay-oauth-implementation/jobs/*.php app/Jobs/
print_success "Jobs copied"

echo ""
echo "Step 5: Copying controller files..."
cp ebay-oauth-implementation/controllers/*.php app/Http/Controllers/
print_success "Controllers copied"

echo ""
echo "Step 6: Copying console command..."
cp ebay-oauth-implementation/commands/*.php app/Console/Commands/
print_success "Console commands copied"

echo ""
echo "Step 7: Copying Vue components..."
mkdir -p resources/js/Pages/Settings/Partials
cp ebay-oauth-implementation/vue-components/Settings/Index.vue resources/js/Pages/Settings/
cp ebay-oauth-implementation/vue-components/Settings/Partials/*.vue resources/js/Pages/Settings/Partials/
print_success "Vue components copied"

echo ""
echo "Step 8: Adding routes to web.php..."
if grep -q "integrations.ebay.callback" routes/web.php; then
    print_warning "Routes already exist in web.php, skipping..."
else
    cat ebay-oauth-implementation/routes/web.php | tail -n +8 >> routes/web.php
    print_success "Routes added to web.php"
fi

echo ""
echo "Step 9: Running migrations..."
docker compose exec -T app php artisan migrate --force
print_success "Migrations completed"

echo ""
echo "Step 10: Clearing caches..."
docker compose exec -T app php artisan config:clear
docker compose exec -T app php artisan route:clear
docker compose exec -T app php artisan view:clear
docker compose exec -T app php artisan cache:clear
print_success "Caches cleared"

echo ""
echo "Step 11: Building frontend assets..."
docker compose exec -T app npm run build
print_success "Frontend assets built"

echo ""
echo "Step 12: Restarting services..."
docker compose restart scheduler
docker compose restart horizon
print_success "Services restarted"

echo ""
echo "========================================"
echo "Deployment Complete! 🎉"
echo "========================================"
echo ""
echo "Next steps:"
echo "1. Visit: http://192.168.1.57:8090/settings"
echo "2. Add your eBay credentials"
echo "3. Connect to eBay"
echo ""
echo "For more information, see:"
echo "- README.md"
echo "- DEPLOYMENT_GUIDE.md"
echo "- QUICK_REFERENCE.md"
echo ""
print_success "Happy coding!"
