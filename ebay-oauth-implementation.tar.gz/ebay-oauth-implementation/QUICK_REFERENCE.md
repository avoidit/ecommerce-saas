# eBay OAuth Integration - Quick Reference

## File Structure

```
ecommerce-saas/
├── app/
│   ├── Console/
│   │   └── Commands/
│   │       └── RefreshOAuthTokensCommand.php
│   ├── Http/
│   │   └── Controllers/
│   │       ├── SettingsController.php
│   │       ├── IntegrationController.php
│   │       └── EbayOAuthController.php
│   ├── Jobs/
│   │   └── RefreshOAuthTokens.php
│   ├── Models/
│   │   ├── TenantSetting.php
│   │   ├── IntegrationCredential.php
│   │   └── OAuthToken.php
│   └── Services/
│       └── EbayOAuthService.php
├── database/
│   └── migrations/
│       ├── 2024_12_07_000001_create_tenant_settings_table.php
│       ├── 2024_12_07_000002_create_integration_credentials_table.php
│       └── 2024_12_07_000003_create_oauth_tokens_table.php
└── resources/
    └── js/
        └── Pages/
            └── Settings/
                ├── Index.vue
                └── Partials/
                    ├── IntegrationsTab.vue
                    └── GeneralTab.vue
```

## Quick Commands

### Run Migrations
```bash
docker compose exec app php artisan migrate
```

### Refresh Tokens Manually
```bash
docker compose exec app php artisan oauth:refresh-tokens
```

### Build Frontend
```bash
docker compose exec app npm run build
```

### Clear Caches
```bash
docker compose exec app php artisan optimize:clear
```

### View Routes
```bash
docker compose exec app php artisan route:list | grep -E 'settings|integration|ebay'
```

### Check Scheduler
```bash
docker compose exec scheduler php artisan schedule:list
```

### Check Horizon
```bash
docker compose exec horizon php artisan horizon:status
```

## Important URLs

- **Settings Page:** http://192.168.1.57:8090/settings
- **eBay Sandbox Callback:** http://192.168.1.57:8090/integrations/ebay/sandbox/callback
- **eBay Production Callback:** http://192.168.1.57:8090/integrations/ebay/production/callback
- **eBay Developer Portal:** https://developer.ebay.com/my/keys
- **Horizon Dashboard:** http://192.168.1.57:8090/horizon
- **Telescope Dashboard:** http://192.168.1.57:8090/telescope

## API Endpoints

### Settings
- `GET /settings` - View settings page
- `PUT /settings/general` - Update general settings

### Integrations
- `POST /settings/integrations` - Create integration
- `PUT /settings/integrations/{id}` - Update integration
- `DELETE /settings/integrations/{id}` - Delete integration
- `POST /settings/integrations/{id}/verify` - Verify credentials

### eBay OAuth
- `GET /integrations/ebay/{env}/callback` - OAuth callback
- `POST /integrations/ebay/{env}/disconnect` - Disconnect
- `POST /integrations/ebay/{env}/refresh` - Manual refresh

## Database Tables

### tenant_settings
Stores team-level configuration settings.

### integration_credentials
Stores encrypted OAuth credentials per platform/environment.

### oauth_tokens
Stores encrypted OAuth tokens with automatic refresh.

## Environment Variables

No additional environment variables needed! Everything is configured in the database.

## Scopes Requested

All eBay API scopes:
- `sell.inventory` - Inventory management
- `sell.fulfillment` - Order fulfillment
- `sell.account` - Account management
- `sell.marketing` - Marketing campaigns
- `sell.analytics.readonly` - Analytics data
- `sell.finances` - Financial data
- `sell.payment.dispute` - Payment disputes
- `commerce.identity.readonly` - User identity

## Security Features

✅ Encrypted credentials in database
✅ Encrypted OAuth tokens
✅ State parameter validation (10-minute expiry)
✅ Team-based authorization
✅ Automatic token refresh
✅ Token expiry monitoring

## Common Tasks

### Add a new platform integration
1. Create service class extending base OAuth pattern
2. Add platform to `availablePlatforms` in SettingsController
3. Create callback route
4. Update IntegrationsTab.vue

### Test token refresh
```bash
# Get a token ID from database
docker compose exec app php artisan tinker
>>> $token = App\Models\OAuthToken::first()
>>> $service = new App\Services\EbayOAuthService($token->integrationCredential)
>>> $service->refreshToken($token)
```

### Debug OAuth flow
1. Check Laravel logs: `docker compose logs -f app`
2. Check callback URL in eBay Developer Portal
3. Verify state parameter isn't expired
4. Check credentials are correct

### Monitor background jobs
```bash
# View Horizon dashboard
open http://192.168.1.57:8090/horizon

# Or check from CLI
docker compose exec horizon php artisan horizon:status
```

## Troubleshooting Checklist

- [ ] Migrations run successfully
- [ ] Routes registered (check with `route:list`)
- [ ] Frontend assets built (`npm run build`)
- [ ] Scheduler container running
- [ ] Horizon container running
- [ ] eBay redirect URIs configured
- [ ] eBay credentials correct
- [ ] SSL configured (for production)
- [ ] Logs show no errors

## Next Steps

1. Test sandbox integration thoroughly
2. Set up production eBay credentials
3. Configure SSL for production
4. Add Amazon integration (follow same pattern)
5. Add Newegg integration (follow same pattern)
6. Set up monitoring/alerts for failed refreshes
7. Document API usage for developers

## Support

- Laravel Docs: https://laravel.com/docs/11.x
- eBay API Docs: https://developer.ebay.com/develop/apis
- Inertia.js Docs: https://inertiajs.com
- Vue.js 3 Docs: https://vuejs.org
