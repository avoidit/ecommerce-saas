# eBay OAuth Integration for E-commerce SaaS

A complete, production-ready OAuth integration system for your Laravel 11 e-commerce SaaS platform.

## 🎯 Overview

This integration provides:
- ✅ **Multi-tenant OAuth** - Supports team-level and user-level connections
- ✅ **Multi-environment** - Sandbox and production support
- ✅ **Secure** - Encrypted credentials and tokens
- ✅ **Automatic token refresh** - Background job handles token renewal
- ✅ **Extensible** - Easy to add more platforms (Amazon, Newegg, etc.)
- ✅ **Scalable settings system** - Built for future growth

## 📋 What's Included

### Backend Components
- **3 Database Migrations** - For settings, credentials, and tokens
- **3 Models** - TenantSetting, IntegrationCredential, OAuthToken
- **1 Service** - EbayOAuthService for OAuth flow
- **3 Controllers** - Settings, Integration, EbayOAuth
- **1 Job** - RefreshOAuthTokens for background processing
- **1 Command** - Manual token refresh command

### Frontend Components
- **Settings Page** - Tabbed interface for all settings
- **Integrations Tab** - Manage platform connections
- **General Settings Tab** - Team preferences
- **Modal Forms** - Add/edit integrations

### Features
- 🔐 **Encrypted Storage** - All credentials and tokens encrypted at rest
- 🔄 **Auto Refresh** - Tokens refresh automatically before expiry
- 🎨 **Dark Mode** - Full dark mode support
- 📱 **Responsive** - Works on all devices
- ⚡ **Real-time Updates** - Uses Inertia.js for SPA experience

## 🚀 Quick Start

### 1. Extract Files
```bash
cd ~/ecommerce-saas
# Extract the implementation files to your project
```

### 2. Run Migrations
```bash
docker compose exec app php artisan migrate
```

### 3. Copy Files
See [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for detailed instructions.

### 4. Build Assets
```bash
docker compose exec app npm run build
```

### 5. Configure eBay
1. Get credentials from https://developer.ebay.com/my/keys
2. Add redirect URI: `http://192.168.1.57:8090/integrations/ebay/sandbox/callback`
3. Add integration in Settings page

## 📚 Documentation

- **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** - Complete step-by-step deployment instructions
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Quick command reference and troubleshooting

## 🏗️ Architecture

### Database Schema

```
tenant_settings (team-level settings)
├── team_id
├── category (general, notifications, warehouse, etc.)
├── key (setting name)
├── value (setting value)
└── type (string, boolean, json, encrypted)

integration_credentials (OAuth credentials)
├── team_id
├── platform (ebay, amazon, newegg)
├── environment (sandbox, production)
├── client_id (encrypted)
├── client_secret (encrypted)
└── config (JSON for platform-specific settings)

oauth_tokens (OAuth access tokens)
├── team_id
├── user_id (null for team-level)
├── integration_credential_id
├── platform
├── environment
├── access_token (encrypted)
├── refresh_token (encrypted)
├── expires_at
└── scopes (JSON array)
```

### OAuth Flow

```
User clicks "Connect" 
    → Redirects to eBay
    → User authorizes
    → eBay redirects to callback
    → Exchange code for token
    → Store encrypted token
    → Success!

Background Job (every 5 min)
    → Find tokens expiring soon
    → Refresh with refresh_token
    → Update stored token
```

## 🔧 Configuration

### eBay Scopes
All scopes are requested by default:
- Inventory Management
- Order Fulfillment
- Account Management
- Marketing
- Analytics
- Finances
- Payment Disputes
- Identity

### Token Refresh
- Runs every 5 minutes via Laravel Scheduler
- Refreshes tokens expiring within 5 minutes
- Handles errors gracefully
- Logs all operations

## 🎨 User Interface

### Settings Page Structure
```
Settings
├── Integrations Tab
│   ├── Platform List
│   ├── Add Integration Modal
│   ├── Edit Integration Modal
│   └── Connection Status
├── General Settings Tab
│   ├── Company Info
│   ├── Timezone
│   └── Currency
├── Notifications Tab (placeholder)
└── Warehouse Tab (placeholder)
```

## 📊 Usage Example

### Access Settings
Navigate to: `http://192.168.1.57:8090/settings`

### Add eBay Integration
1. Click "Add Integration"
2. Select "eBay" and "Sandbox"
3. Enter App ID and Cert ID
4. Click "Add Integration"

### Connect to eBay
1. Click "Connect" button
2. Authorize on eBay
3. Done! Token is stored securely

### Programmatic API Usage
```php
use App\Models\OAuthToken;
use App\Services\EbayOAuthService;

// Get active token
$token = OAuthToken::getActiveToken(
    teamId: $team->id,
    platform: 'ebay',
    environment: 'sandbox'
);

// Make API request
$service = new EbayOAuthService($token->integrationCredential);
$inventory = $service->apiRequest('get', '/sell/inventory/v1/inventory_item');
```

## 🔐 Security

### Encryption
- All credentials encrypted with Laravel's encryption
- All tokens encrypted with Laravel's encryption
- Uses `APP_KEY` from `.env`

### Authorization
- Team owners only can add/edit integrations
- Uses Laravel's built-in authorization gates
- State parameter validates OAuth flow (10-minute expiry)

### Best Practices
- Never commit credentials to git
- Rotate keys regularly
- Use HTTPS in production
- Monitor token refresh logs
- Set up alerts for failures

## 🌟 Extensibility

### Adding New Platforms

1. **Add Credentials**
```php
IntegrationCredential::create([
    'team_id' => $teamId,
    'platform' => 'amazon',
    'environment' => 'production',
    'client_id' => $clientId,
    'client_secret' => $clientSecret,
]);
```

2. **Create Service**
```php
class AmazonOAuthService extends BaseOAuthService
{
    // Implement OAuth flow
}
```

3. **Add Routes**
```php
Route::get('/integrations/amazon/callback', ...);
```

4. **Update UI**
```javascript
availablePlatforms: {
    amazon: { ... }
}
```

### Adding New Settings

1. **Add to Database**
```php
TenantSetting::set($teamId, 'warehouse', 'location', 'Chicago, IL');
```

2. **Add to UI**
```vue
<template>
    <WarehouseTab :settings="warehouseSettings" />
</template>
```

## 🐛 Troubleshooting

### Common Issues

**OAuth callback fails**
- Check redirect URI matches exactly in eBay Developer Portal
- Verify no trailing slash
- Check Laravel logs for details

**Token refresh fails**
- Verify Horizon is running
- Check scheduler is active
- Review Laravel logs

**Credentials verification fails**
- Double-check App ID and Cert ID
- Ensure correct environment (sandbox vs production)
- Verify credentials are active in eBay Developer Portal

## 📈 Roadmap

- [x] eBay OAuth integration
- [x] Encrypted credential storage
- [x] Automatic token refresh
- [x] Multi-tenant support
- [ ] Amazon integration
- [ ] Newegg integration
- [ ] Shopify integration
- [ ] Webhook support
- [ ] Rate limiting per platform
- [ ] API usage analytics

## 🤝 Contributing

This is built specifically for your e-commerce SaaS, but the architecture is designed to be:
- Maintainable
- Testable
- Extensible
- Scalable

## 📄 License

Proprietary - Built for your e-commerce SaaS platform

## 🆘 Support

For issues:
1. Check [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)
2. Check [QUICK_REFERENCE.md](QUICK_REFERENCE.md)
3. Review Laravel logs
4. Check Horizon dashboard
5. Check Telescope dashboard

## 🎉 Success Criteria

You'll know it's working when:
- ✅ Settings page loads at /settings
- ✅ You can add eBay credentials
- ✅ You can connect to eBay
- ✅ Token appears in database (encrypted)
- ✅ Token refreshes automatically
- ✅ You can make API requests to eBay

## 📝 Notes

- Built for Laravel 11, PHP 8.4, Vue.js 3
- Uses PostgreSQL for database
- Uses Redis for caching and queues
- Follows Laravel and Jetstream conventions
- Production-ready and battle-tested patterns

---

**Built with ❤️ for scalable e-commerce**
