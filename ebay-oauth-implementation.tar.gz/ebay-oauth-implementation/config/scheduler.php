<?php

/*
|--------------------------------------------------------------------------
| Task Scheduling - Add to app/Console/Kernel.php
|--------------------------------------------------------------------------
|
| Add this to the schedule() method in your Kernel.php file
|
*/

protected function schedule(Schedule $schedule): void
{
    // Refresh OAuth tokens every 5 minutes
    $schedule->command('oauth:refresh-tokens')
        ->everyFiveMinutes()
        ->withoutOverlapping()
        ->runInBackground();
}
