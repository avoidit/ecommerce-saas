<?php

use App\Http\Controllers\SettingsController;
use App\Http\Controllers\IntegrationController;
use App\Http\Controllers\EbayOAuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Settings & Integration Routes
|--------------------------------------------------------------------------
|
| Add these routes to your web.php file
|
*/

Route::middleware(['auth:sanctum', config('jetstream.auth_session'), 'verified'])->group(function () {
    
    // Settings
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::put('/settings/general', [SettingsController::class, 'updateGeneralSettings'])->name('settings.general.update');

    // Integration Credentials Management
    Route::prefix('settings/integrations')->name('integrations.')->group(function () {
        Route::post('/', [IntegrationController::class, 'store'])->name('store');
        Route::put('/{credential}', [IntegrationController::class, 'update'])->name('update');
        Route::delete('/{credential}', [IntegrationController::class, 'destroy'])->name('destroy');
        Route::post('/{credential}/verify', [IntegrationController::class, 'verifyCredentials'])->name('verify');
    });

    // eBay OAuth
    Route::prefix('integrations/ebay')->name('integrations.ebay.')->group(function () {
        Route::get('/{environment}/callback', [EbayOAuthController::class, 'callback'])->name('callback');
        Route::post('/{environment}/disconnect', [EbayOAuthController::class, 'disconnect'])->name('disconnect');
        Route::post('/{environment}/refresh', [EbayOAuthController::class, 'refreshToken'])->name('refresh');
    });
});
